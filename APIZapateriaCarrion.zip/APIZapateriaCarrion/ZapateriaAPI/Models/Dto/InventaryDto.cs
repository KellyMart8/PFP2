﻿namespace ZapateriaAPI.Models.Dto
{
    public class InventaryDto
    {
        public int IDInventario { get; set; }
        public int IDProducto { get; set; }
        public int Cantidad { get; set; }
    }
}
