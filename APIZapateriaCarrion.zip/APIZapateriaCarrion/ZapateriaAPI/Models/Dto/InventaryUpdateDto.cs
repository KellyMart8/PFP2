﻿namespace ZapateriaAPI.Models.Dto
{
    public class InventaryUpdateDto
    {
        public int IDInventario { get; set; }
        public int IDProducto { get; set; }
        public int Cantidad { get; set; }
    }
}
