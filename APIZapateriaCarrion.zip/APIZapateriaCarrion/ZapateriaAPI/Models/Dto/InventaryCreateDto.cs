﻿namespace ZapateriaAPI.Models.Dto
{
    public class InventaryCreateDto
    {
        public int IDProducto { get; set; }
        public int Cantidad { get; set; }
    }
}
